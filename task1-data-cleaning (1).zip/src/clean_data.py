import pandas as pd

# Load dataset
df = pd.read_csv("data/mall_customers.csv")

# Handle missing values
df = df.dropna(subset=["CustomerID"])
df["Age"].fillna(df["Age"].mean(), inplace=True)
df["Annual Income (k$)"].fillna(df["Annual Income (k$)"].mean(), inplace=True)
df["Spending Score (1-100)"].fillna(df["Spending Score (1-100)"].mean(), inplace=True)

# Remove duplicates
df = df.drop_duplicates()

# Standardize Gender column
df["Gender"] = df["Gender"].str.strip().str.lower().replace({
    "m": "male", "f": "female"
})

# Rename columns
df.rename(columns={
    "Annual Income (k$)": "annual_income_k",
    "Spending Score (1-100)": "spending_score"
}, inplace=True)

# Ensure datatypes
df["CustomerID"] = df["CustomerID"].astype(int)
df["Age"] = df["Age"].astype(int)
df["annual_income_k"] = df["annual_income_k"].astype(int)
df["spending_score"] = df["spending_score"].astype(int)

# Save cleaned dataset
df.to_csv("data/mall_customers_cleaned.csv", index=False)
print("✅ Data cleaning complete! Cleaned file saved as data/mall_customers_cleaned.csv")
